import React, { useState } from 'react';
import Logo from "../Images/Logo.png";
import '../Styles/Login.css';

function Login({ setUser }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [role, setRole] = useState('student');
  const [isSignup, setIsSignup] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    // Dummy validation for now, replace with real API call for login
    if (username === 'admin' && password === 'admin') {
      // Assuming admin is a professor
      setUser({
        username,
        role: 'prof',
        firstName: 'John',
        lastName: 'Doe',
      });
    } else if (username === 'student' && password === 'student') {
      // Assuming student is a regular user
      setUser({
        username,
        role: 'student',
        firstName: 'Jane',
        lastName: 'Smith',
      });
    } else {
      setError('Invalid username or password');
    }

    // Clear form after submission
    setUsername('');
    setPassword('');
    setFirstName('');
    setLastName('');
  };

  return (
    <div className="login-container">
      <img className="logo" src={Logo} alt="Esl ai Logo" />
      <div className={`form-container ${isSignup ? 'signup-form' : 'login-form'}`}>
        {isSignup ? (
          <>
            <h2 className="form-title">Inscription</h2>
            <form onSubmit={handleSubmit}>
              <label htmlFor="first-name">Nom</label>
              <input
                type="text"
                id="first-name"
                placeholder="Écrivez votre nom"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
              />
              <label htmlFor="last-name">Prénom</label>
              <input
                type="text"
                id="last-name"
                placeholder="Écrivez votre prénom"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
              />
              <label htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                placeholder="Écrivez votre username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <label htmlFor="password">Mot de passe</label>
              <input
                type="password"
                id="password"
                placeholder="Écrivez votre mot de passe"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <label htmlFor="confirm-password">Confirmation de mot de passe</label>
              <input
                type="password"
                id="confirm-password"
                placeholder="Confirmez votre mot de passe"
              />
              <div className="radio-group">
                <label>
                  <input
                    type="radio"
                    value="student"
                    checked={role === 'student'}
                    onChange={() => setRole('student')}
                  />
                  Étudiant
                </label>
                <label>
                  <input
                    type="radio"
                    value="prof"
                    checked={role === 'prof'}
                    onChange={() => setRole('prof')}
                  />
                  Professeur
                </label>
              </div>
              <button type="submit" className="submit">S'inscrire</button>
            </form>
          </>
        ) : (
          <>
            <h2 className="form-title">Connexion</h2>
            <form onSubmit={handleSubmit}>
              <label htmlFor="username">Username</label>
              <input
                type="text"
                id="username"
                placeholder="Écrivez votre username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <label htmlFor="password">Mot de passe</label>
              <input
                type="password"
                id="password"
                placeholder="Écrivez votre mot de passe"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button type="submit" className="submit">Se connecter</button>
            </form>
            {error && <p style={{ color: 'red' }}>{error}</p>}
          </>
        )}

        <div className="toggle">
          {isSignup ? (
            <p>Vous avez déjà un compte? <span onClick={() => setIsSignup(false)}>Se connecter</span></p>
          ) : (
            <p>Vous n'avez pas un compte? <span onClick={() => setIsSignup(true)}>Créez un compte</span></p>
          )}
        </div>
      </div>
    </div>
  );
}

export default Login;
