import React, { useState } from "react";
import { Routes, Route, BrowserRouter as Router, Navigate } from "react-router-dom";
import ServicesSection from "./Components/ServicesSection";
import ContactForm from "./Components/ContactForm";
import Testimonials from "./Components/Testimonials";
import Footer from "./Components/Footer";
import Navbar2 from "./Components/Navbar2";
import Section from "./Components/Section";
import Equipes from "./Components/Equipes";
import ProjectManagement from "./Components/ProjectManagement";
import Faq from "./Components/Faq";
import BoiteMessage from "./Components/BoiteMessage";
import Guide from "./Components/Guide";
import Login from "./Components/Login"; // Import the Login component

import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [user, setUser] = useState(null); // Store logged-in user data

  return (
    <Router>
      <div className="app">
        {/* Show Navbar only after the user is logged in */}
        {user && <Navbar2 />}

        <main className="content">
          <Routes>
            {/* Show the Login page if the user is not logged in */}
            <Route path="/" element={user ? <Navigate to="/equipes" /> : <Login setUser={setUser} />} />
            
            {/* Protected Routes */}
            <Route path="/services" element={user ? <ServicesSection /> : <Navigate to="/" />} />
            <Route path="/Equipes" element={user ? <Equipes /> : <Navigate to="/" />} />
            <Route path="/Projets" element={user ? <ProjectManagement /> : <Navigate to="/" />} />
            <Route path="/FAQ" element={user ? <Faq /> : <Navigate to="/" />} />
            <Route path="/BoiteMessage" element={user ? <BoiteMessage /> : <Navigate to="/" />} />
            <Route path="/Guide" element={user ? <Guide /> : <Navigate to="/" />} />

            {/* Redirect to login if no route matches */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
